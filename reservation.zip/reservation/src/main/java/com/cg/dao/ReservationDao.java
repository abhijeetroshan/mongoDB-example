package com.cg.dao;

import com.cg.bean.Reservation;
import com.cg.exception.ReservationException;

public interface ReservationDao {

//	READ THE DETAILS OF THE RESERVATION
	Reservation readDetails(String pnrNo) throws ReservationException;

}