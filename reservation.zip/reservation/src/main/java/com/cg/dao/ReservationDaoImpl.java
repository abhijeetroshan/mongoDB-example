package com.cg.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.bean.Reservation;
import com.cg.exception.ReservationException;

@Repository
public class ReservationDaoImpl implements ReservationDao {

	@Autowired
	MongoTemplate mongoTemplate;

	
//	METHOD FOR READ DETAILS
	@Override
	public Reservation readDetails(String pnrNo) throws ReservationException {
		Reservation rd = mongoTemplate.findById(pnrNo, Reservation.class);
		if (rd == null)
			throw new ReservationException("PNR not found wrong PnrNo : " + pnrNo);
		else
			
		return rd;
	}

}//END CLASS
