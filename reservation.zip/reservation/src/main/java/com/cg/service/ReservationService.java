package com.cg.service;

import com.cg.bean.Reservation;
import com.cg.exception.ReservationException;

public interface ReservationService {


	Reservation read(String pnrNo) throws ReservationException;

}
