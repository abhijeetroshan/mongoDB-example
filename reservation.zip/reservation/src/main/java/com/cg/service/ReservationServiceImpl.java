package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Reservation;
import com.cg.dao.ReservationDao;
import com.cg.exception.ReservationException;

@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {
	@Autowired
	ReservationDao reservationDao;

	//FOR READING THE RESERVATION DETAILS
	@Override
	public Reservation read(String pnrNo) throws ReservationException {
		Reservation rd = reservationDao.readDetails(pnrNo);
		if (rd == null) {
			throw new ReservationException("PNR Number not found: "+pnrNo);
		}
		return rd;
	}

}
