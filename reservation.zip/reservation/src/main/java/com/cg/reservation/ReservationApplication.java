package com.cg.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//PACKAGE SCANNER
@SpringBootApplication(scanBasePackages = { "com.cg.dao", "com.cg.exception", "com.cg.reservation",
		"com.cg.service","com.cg.bean" })
public class ReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationApplication.class, args);
	}//END MAIN
}
