package com.cg.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//COLLECTION NAME IN MONGODB
@Document(collection = "Reservation")
public class Reservation {
	@Id
	String pnrNo; // ID OF COLLECTION
	String passenger_name;
	String source_loc;
	String desc_loc;
	int price;

	// GETTER AND SETTER
	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}

	public String getPassenger_name() {
		return passenger_name;
	}

	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}

	public String getSource_loc() {
		return source_loc;
	}

	public void setSource_loc(String source_loc) {
		this.source_loc = source_loc;
	}

	public String getDesc_loc() {
		return desc_loc;
	}

	public void setDesc_loc(String desc_loc) {
		this.desc_loc = desc_loc;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}//END CLASS