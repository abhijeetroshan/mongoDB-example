package com.cg.exception;

//USER  DEFINE EXCEPTION
public class ReservationException extends Exception
{
	String msg;
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public ReservationException(String msg) 
	{
		super(msg);
		this.msg=msg;
	}
}