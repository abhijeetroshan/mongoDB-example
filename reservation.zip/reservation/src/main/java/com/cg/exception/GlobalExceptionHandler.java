package com.cg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

//GLOBAL EXCEPTION
@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { ReservationException.class })
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	protected ReservationException handleConflict(ReservationException se) {
		
		  String status =  se.getMsg();
	        return new ReservationException(status);
	}

}
